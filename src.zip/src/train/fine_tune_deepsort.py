import os
import cv2
import time
import numpy as np
from ultralytics import YOLO
from deep_sort_realtime.deepsort_tracker import DeepSort

def load_yolo_model(model_path):
    """
    Load the YOLOv8 model.
    """
    model = YOLO(model_path)
    return model

def initialize_deepsort(params):
    """
    Initialize the DeepSORT tracker with parameters from a dictionary.
    """
    tracker = DeepSort(max_age=params.get('max_age', 30),
                       n_init=params.get('n_init', 3),
                       nms_max_overlap=params.get('nms_max_overlap', 1.0),
                       max_cosine_distance=params.get('max_cosine_distance', 0.3),
                       nn_budget=params.get('nn_budget', None),
                       override_track_class=params.get('override_track_class', None))
    return tracker

def process_sequence_with_params(seq_path, yolo_model, deepsort_params, output_video_path, target_class_ids=None, confidence_threshold=0.3):
    """
    Process a single sequence folder with DeepSORT using specified parameters.
    """
    img_dir = os.path.join(seq_path, "img1")
    img_files = sorted([f for f in os.listdir(img_dir) if f.endswith('.jpg')])

    seqinfo_path = os.path.join(seq_path, "seqinfo.ini")
    frame_rate = 25
    imWidth = 1280
    imHeight = 720
    if os.path.exists(seqinfo_path):
        with open(seqinfo_path, 'r') as f:
            for line in f:
                if line.startswith("frameRate"):
                    frame_rate = float(line.split('=')[1].strip())
                elif line.startswith("imWidth"):
                    imWidth = int(line.split('=')[1].strip())
                elif line.startswith("imHeight"):
                    imHeight = int(line.split('=')[1].strip())

    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(output_video_path, fourcc, frame_rate, (imWidth, imHeight))

    deepsort_tracker = initialize_deepsort(deepsort_params) # Initialize DeepSORT with current parameters

    for frame_idx, img_file in enumerate(img_files):
        img_path = os.path.join(img_dir, img_file)
        frame = cv2.imread(img_path)
        if frame is None:
            print(f"Warning: Unable to load frame {img_path}")
            continue

        results = yolo_model(frame)[0]

        detections = []
        for result in results:
            boxes = result.boxes.xywh.cpu().numpy()
            confs = result.boxes.conf.cpu().numpy()
            class_ids = result.boxes.cls.cpu().numpy()

            for box, conf, cls in zip(boxes, confs, class_ids):
                if conf > confidence_threshold:
                    if target_class_ids is None or int(cls) in target_class_ids:
                        x_center, y_center, w, h = box
                        x1 = int(x_center - (w / 2))
                        y1 = int(y_center - (h / 2))
                        x2 = int(x_center + (w / 2))
                        y2 = int(y_center + (h / 2))
                        detections.append([[x1, y1, x2 - x1, y2 - y1], conf, cls])

        tracks = deepsort_tracker.update_tracks(detections, frame=frame)

        for track in tracks:
            if not track.is_confirmed():
                continue
            track_id = track.track_id
            bbox = track.to_ltrb()
            cv2.rectangle(frame, (int(bbox[0]), int(bbox[1])), (int(bbox[2]), int(bbox[3])), (0,255,0), 2)
            cv2.putText(frame, f'ID: {track_id}', (int(bbox[0]), int(bbox[1]-10)), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,255,0), 2)

        out.write(frame)
        if frame_idx % 50 == 0:
            print(f"Processed frame {frame_idx}/{len(img_files)}")

    out.release()
    print(f"Output video saved to {output_video_path}")


def tune_deepsort_parameters(seq_folder, yolo_model, output_dir_base, param_ranges, target_class_ids=None, confidence_threshold=0.3):
    """
    Tunes DeepSORT parameters by iterating through parameter ranges and processing a sequence.

    Args:
        seq_folder (str): Path to the sequence folder.
        yolo_model (YOLO): Loaded YOLO model.
        output_dir_base (str): Base directory to save output videos for each parameter set.
        param_ranges (dict): Dictionary defining parameter ranges for tuning.
                             Example:
                             {
                                 'max_age': [10, 20, 30, 40],
                                 'max_cosine_distance': [0.2, 0.3, 0.4],
                                 'n_init': [1, 2, 3]
                             }
        target_class_ids (list, optional): List of class IDs to track. Defaults to None (track all).
        confidence_threshold (float, optional): Confidence threshold for YOLO detections. Defaults to 0.3.
    """

    os.makedirs(output_dir_base, exist_ok=True)

    param_names = list(param_ranges.keys())
    param_values_list = [param_ranges[name] for name in param_names]

    # Generate all combinations of parameter values using recursion
    def generate_combinations(index, current_params):
        if index == len(param_names):
            param_folder_name = "_".join([f"{name}_{current_params[i]}" for i, name in enumerate(param_names)])
            output_video_path = os.path.join(output_dir_base, param_folder_name, "tracked_output.mp4")
            os.makedirs(os.path.dirname(output_video_path), exist_ok=True)

            print(f"\nProcessing with parameters: {current_params}")
            process_sequence_with_params(seq_folder, yolo_model, dict(zip(param_names, current_params)),
                                         output_video_path, target_class_ids, confidence_threshold)
            print(f"Video saved to: {output_video_path}")
            return

        for value in param_values_list[index]:
            current_params.append(value)
            generate_combinations(index + 1, current_params)
            current_params.pop() # Backtrack


    print("Starting parameter tuning...")
    generate_combinations(0, [])
    print("Parameter tuning complete. Check output videos in:", output_dir_base)


# --- Main Script ---
if __name__ == "__main__":
    # Paths (change these paths as needed)
    yolo_model_path = '/home/ubuntu/project_dl/src/runs/detect/train/weights/best.pt' # Path to your trained YOLOv8 model
    seq_folder = '/home/ubuntu/project_dl/dataset/onlyfootball/dataset/val/v_dw7LOz17Omg_c053' # Select a sequence folder for tuning
    output_dir_base = '/home/ubuntu/project_dl/results/tuning_outputs_finetune' # Base directory for output videos

    # --- Define Parameter Ranges to Tune ---
    # Adjust these ranges based on your needs and computational resources
    deepsort_param_ranges = {
        'max_age': [10, 30, 50],      # Test different max_age values
        'max_cosine_distance': [0.2, 0.3, 0.5], # Test different cosine distance thresholds
        'n_init': [1, 3],             # Test different n_init values
        # 'nn_budget': [None, 50, 100] # Example: Tuning nn_budget (can be computationally intensive)
    }

    target_class_ids = [0] # Track only 'person' class (adjust if needed)
    confidence_threshold = 0.3 # Confidence threshold for YOLO detections

    # Load YOLO model
    yolo_model = load_yolo_model(yolo_model_path)

    # Run parameter tuning
    tune_deepsort_parameters(seq_folder, yolo_model, output_dir_base, deepsort_param_ranges, target_class_ids, confidence_threshold)

    print("\n--- Tuning Completed ---")
    print(f"Output videos saved to: {output_dir_base}")
    print("Now, visually review the videos in each subdirectory to assess tracking performance with different parameter sets.")
    print("Choose the parameter set that provides the best visual tracking results for your dataset.")