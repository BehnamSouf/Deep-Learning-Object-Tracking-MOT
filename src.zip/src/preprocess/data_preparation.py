import os
import cv2
import numpy as np
from sklearn.model_selection import train_test_split

# Convert MOT annotations to YOLO format
def mot_to_yolo(mot_path, output_dir, img_width=1280, img_height=720):
    os.makedirs(output_dir, exist_ok=True)
    with open(mot_path) as f:
        for line in f:
            frame, id, x, y, w, h, _, _, _ = map(int, line.strip().split(','))
            
            # Convert to YOLO format
            x_center = (x + w/2) / img_width
            y_center = (y + h/2) / img_height
            width = w / img_width
            height = h / img_height
            
            txt_path = os.path.join(output_dir, f"{frame:06d}.txt")
            with open(txt_path, 'a') as yolo_file:
                yolo_file.write(f"0 {x_center} {y_center} {width} {height}\n")

# Process dataset
for split in ['train', 'val', 'test']:
    for seq in os.listdir(f'/home/ubuntu/project_dl/dataset/sportsmot_publish/dataset/{split}'):
        mot_path = f'/home/ubuntu/project_dl/dataset/sportsmot_publish/dataset/{split}/{seq}/gt/gt.txt'
        if os.path.exists(mot_path):
            output_dir = f'/home/ubuntu/project_dl/dataset/sportsmot_publish/dataset/{split}/{seq}/labels'
            mot_to_yolo(mot_path, output_dir)

# Create dataset.yaml
yaml_content = """
path: /home/ubuntu/project_dl/dataset/sportsmot_publish/dataset
train: train
val: val
test: test

names:
  0: player
"""

with open('dataset.yaml', 'w') as f:
    f.write(yaml_content)
    