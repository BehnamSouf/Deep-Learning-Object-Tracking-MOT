import cv2
import os
import configparser

# Paths
img_folder = "/home/ubuntu/project_dl/dataset/onlyfootball/dataset/val/v_dw7LOz17Omg_c053/img1"
seqinfo_path = "/home/ubuntu/project_dl/dataset/onlyfootball/dataset/val/v_dw7LOz17Omg_c053/seqinfo.ini"
output_video = "v_dw7LOz17Omg_c053.mp4"

# Read frame rate from seqinfo.ini
config = configparser.ConfigParser()
config.read(seqinfo_path)
frame_rate = int(config["Sequence"]["frameRate"])

# Get sorted list of image files
images = sorted([img for img in os.listdir(img_folder) if img.endswith((".jpg", ".png"))])

# Read first image to get frame size
first_img = cv2.imread(os.path.join(img_folder, images[0]))
height, width, layers = first_img.shape

# Define video writer
fourcc = cv2.VideoWriter_fourcc(*"mp4v")  # Codec for MP4
video = cv2.VideoWriter(output_video, fourcc, frame_rate, (width, height))

# Write frames to video
for img in images:
    frame = cv2.imread(os.path.join(img_folder, img))
    video.write(frame)

# Release video writer
video.release()
print(f"Video saved as {output_video}")
