import cv2
import os
import numpy as np

# Paths
frames_folder = "/home/ubuntu/project_dl/dataset/onlyfootball/dataset/test/v_2ChiYdg5bxI_c602/img1"
tracking_file = "/home/ubuntu/project_dl/Deep-EIoU/DeepEIoU_SportsMOT_Split+Connect_eps0.6_minSamples10_K3_mergeDist0.4_spatial1.0/v_2ChiYdg5bxI_c602.txt"
output_video = "/home/ubuntu/project_dl/Deep-EIoU/results/output_tracking_v_2ChiYdg5bxI_c602_GTA_DeepEIoU.mp4"

# Load tracking data
tracking_data = {}
with open(tracking_file, 'r') as f:
    for line in f:
        values = line.strip().split(',')
        # frame_id = int(values[0])
        frame_id = int(float(values[0]))
        track_id = int(values[1])
        x, y, w, h = map(float, values[2:6])
        
        if frame_id not in tracking_data:
            tracking_data[frame_id] = []
        tracking_data[frame_id].append((track_id, x, y, w, h))

# Get frame list and sort
frame_files = sorted([f for f in os.listdir(frames_folder) if f.endswith(".jpg")])
if not frame_files:
    raise ValueError("No frames found in the folder")

# Get frame size
sample_frame = cv2.imread(os.path.join(frames_folder, frame_files[0]))
frame_height, frame_width, _ = sample_frame.shape

# Video writer
fourcc = cv2.VideoWriter_fourcc(*'mp4v')
out = cv2.VideoWriter(output_video, fourcc, 30, (frame_width, frame_height))

# Process frames
for i, frame_file in enumerate(frame_files, start=1):
    frame_path = os.path.join(frames_folder, frame_file)
    frame = cv2.imread(frame_path)
    
    if i in tracking_data:
        for track in tracking_data[i]:
            track_id, x, y, w, h = track
            x1, y1, x2, y2 = int(x), int(y), int(x + w), int(y + h)
            
            # Draw bounding box and label
            color = (0, 255, 0)
            cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
            cv2.putText(frame, f'ID: {track_id}', (x1, y1 - 10), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 2)
    
    # Write the frame to the output video
    out.write(frame)

# Release the video writer
out.release()
print("Video saved as", output_video)