import os
import shutil

dataset_root = "/home/ubuntu/project_dl/dataset/onlyvolleyball/dataset"
splits_txt_football = "/home/ubuntu/project_dl/dataset/sportsmot_publish/splits_txt/volleyball.txt"
folders_to_process = ["test", "train", "val"]

# Read video IDs from football.txt
with open(splits_txt_football, 'r') as f:
    football_video_ids = [line.strip() for line in f]

for folder in folders_to_process:
    folder_path = os.path.join(dataset_root, folder)
    subfolders = [f for f in os.listdir(folder_path) if os.path.isdir(os.path.join(folder_path, f))]

    for subfolder in subfolders:
        if subfolder not in football_video_ids:
            subfolder_full_path = os.path.join(folder_path, subfolder)
            print(f"Removing folder: {subfolder_full_path}")
            shutil.rmtree(subfolder_full_path)

print("Done removing folders not in football.txt")