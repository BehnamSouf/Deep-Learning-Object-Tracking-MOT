SOURCE_DIR="/home/ubuntu/project_dl/dataset/onlyfootball/dataset/test"
TARGET_IMAGES_DIR="$SOURCE_DIR/images"
# TARGET_LABELS_DIR="$SOURCE_DIR/labels"

# Create target directories if they don't exist
mkdir -p "$TARGET_IMAGES_DIR"
# mkdir -p "$TARGET_LABELS_DIR"

find "$SOURCE_DIR" -maxdepth 1 -mindepth 1 -type d | while read SUBFOLDER; do
  SUBFOLDER_NAME=$(basename "$SUBFOLDER")
  IMG_SRC_DIR="$SUBFOLDER/img1"
#   LABEL_SRC_DIR="$SUBFOLDER/labels"

  echo "Processing folder: $SUBFOLDER_NAME"

  find "$IMG_SRC_DIR" -type f -name "*.jpg" | while read IMG_FILE; do
    FILENAME=$(basename "$IMG_FILE")
    NEW_FILENAME="${SUBFOLDER_NAME}_${FILENAME}"
    cp "$IMG_FILE" "$TARGET_IMAGES_DIR/$NEW_FILENAME"
    echo "  Copied image: $FILENAME to $TARGET_IMAGES_DIR/$NEW_FILENAME"
  done

#   find "$LABEL_SRC_DIR" -type f -name "*.txt" | while read LABEL_FILE; do
#     FILENAME=$(basename "$LABEL_FILE")
#     NEW_FILENAME="${SUBFOLDER_NAME}_${FILENAME}"
#     cp "$LABEL_FILE" "$TARGET_LABELS_DIR/$NEW_FILENAME"
#     echo "  Copied label: $FILENAME to $TARGET_LABELS_DIR/$NEW_FILENAME"
#   done
done

echo "Finished moving and renaming files."